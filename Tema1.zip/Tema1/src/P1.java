import java.io.*;
import java.util.*;
import java.lang.*;

public class P1 {
	static class Task {
		public final static String INPUT_FILE = "p1.in";
		public final static String OUTPUT_FILE = "p1.out";

		int n;
		int[] v;

		private void readInput() {
			try {
				Scanner sc = new Scanner(new File(INPUT_FILE));
				n = sc.nextInt();
				v = new int[n + 1];
				for (int i = 1; i <= n; i++) {
					v[i] = sc.nextInt();
				}
				sc.close();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		private void writeOutput(int result) {
			try {
				PrintWriter pw = new PrintWriter(new File(OUTPUT_FILE));
				pw.printf("%d\n", result);
				pw.close();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		private int getResult(){
			int tuzgu = 0, ritza = 0, i = 0;

			//Sortez sirul
			Arrays.sort(v);
			for (i = n; i >= 1; i--){
				//Daca in sir este un numar par de elemente
				if (n % 2 == 0){
					//Adaug numerele de la pozitile pare lui tuzgu
					if (i % 2 == 0)
						tuzgu += v[i];
					//Si adaug numerele de la pozitile impare lui ritza
					else ritza += v[i];
				}
				//Daca in sir este un numar impar de element
				else{
					//Adaug numerele de la pozitile impare lui tuzgu
					if (i % 2 == 1)
						tuzgu += v[i];
					//Si adaug numerele de la pozitile pare lui ritza
					else ritza += v[i];
				}
			}
			return (tuzgu - ritza);
		}

		public void solve() {
			readInput();
			writeOutput(getResult());
		}
	}

	public static void main(String[] args) {
		new Task().solve();
	}
}