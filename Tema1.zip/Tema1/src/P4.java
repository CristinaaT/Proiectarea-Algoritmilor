import java.io.*;
import java.util.*;
import java.lang.*;

public class P4 {
	static class Task {
		public final static String INPUT_FILE = "P4.in";
		public final static String OUTPUT_FILE = "P4.out";

		int n, k, val_max;
		private void readInput() {
			try {
				Scanner sc = new Scanner(new File(INPUT_FILE));
				n = sc.nextInt();
				k = sc.nextInt();
				val_max = sc.nextInt();
				sc.close();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
		

		private void writeOutput(int result) {
			try {
				PrintWriter pw = new PrintWriter(new File(OUTPUT_FILE));
				pw.printf("%d\n", result);
				pw.close();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		private long fact(int number){
			long ans = 1;
			int i = 0;
			for (i = 2; i <= number; i++)
				ans *= i;
			return ans;
		}

		private int getDiff(int[] v){
			int tuzgu = 0, ritza = 0, i = 0;
			//Sortez sirul
			Arrays.sort(v);
			for (i = n; i >= 1; i--){
				//Daca in sir este un numar par de elemente
				if (n % 2 == 0){
					//Adaug numerele de la pozitile pare lui tuzgu
					if (i % 2 == 0)
						tuzgu += v[i];
					//Si adaug numerele de la pozitile impare lui ritza
					else ritza += v[i];
				}
				//Daca in sir este un numar impar de element
				else{
					//Adaug numerele de la pozitile impare lui tuzgu
					if (i % 2 == 1)
						tuzgu += v[i];
					//Si adaug numerele de la pozitile pare lui ritza
					else ritza += v[i];
				}
			}
			return (tuzgu - ritza);
		}

		//Functie ce verifica daca elementul x se afla in array-ul v
		private boolean contains(int[] v, int x){
			int i = 0;
			for (i = 0; i < v.length; i++){
				if (v[i] == x)
					return true;
			}
			return false; 
		}

		//Functie ce genereaza un array random, de dimensiune size,
		//cu elemente distincte min <= x <= max
		private int[] getRandomArray(int size, int min, int max){
			int i = 0, tmp = 0;
			int[] v = new int[size+1];
			Random r = new Random();
			for (i = 0; i < size; i++){
				//Verific ca elementul sa nu fie deja in array
				while(true){
					tmp = r.nextInt(max - min + 1) + min;
					if (contains(v, tmp) == false)
						break;
				}
				v[i] = tmp;
			}
			return v;
		}

		//Functie ce verifica daca array-ul v se afla in lista list
		private boolean contains(List<int[]> list, int[] v){
			int i = 0;
			int [] a = new int[n];
			for (i = 0; i < list.size(); i++){
				a = list.get(i);
				if (Arrays.equals(a, v) == true)
					return true;
			}
			return false;
		}

		//Numarul de siruri posibile este Aranjamente de val_max
		//luate cate n, astfel ca incerc sa le gasesc pe toate
		private int getResult(){
			int ans = 0, i = 0;
			int[] v = new int[n];
			long max = fact(val_max) / fact(val_max - n);
			List<int[]> list = new ArrayList<int[]>();

			while (i <= max * 2){
				v = getRandomArray(n, 1, val_max);
				if (contains(list, v) == false){
					list.add(v);
					if (getDiff(v) == k)
						ans++;
				}
				i++;
			}

			return 0;
		}

		public void solve() {
			readInput();
			writeOutput(getResult());
		}

	}

	public static void main(String[] args) {
		new Task().solve();
	}
}