import java.io.*;
import java.util.*;
import java.lang.*;

public class P3 {
	static class Task {

		//First = scorul primului jucator la momentul curent
		//Second = scorul celui de-al doilea jucator la momentul curent
		static class Players{
			long first;
			long second;

			public Players(long x, long y){
				first = x;
				second = y;
			}	
		}

		public final static String INPUT_FILE = "p3.in";
		public final static String OUTPUT_FILE = "p3.out";

		int n;
		int[] v;

		private void readInput() {
			try {
				Scanner sc = new Scanner(new File(INPUT_FILE));
				n = sc.nextInt();
				v = new int[n];
				for (int i = 0; i < n; i++) {
					v[i] = sc.nextInt();
				}
				sc.close();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		private void writeOutput(long result) {
			try {
				PrintWriter pw = new PrintWriter(new File(OUTPUT_FILE));
				pw.printf("%d\n", result);
				pw.close();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		private long getResult(){
            int i = 0, j = 0, k = 0;
            Players[][] dp = new Players[n][n];
            
            //Pentru inceput, matricea dp va contine v[i] pe diagonala principala
            for (i = 0; i < n; i++)
                for (j = 0; j < n; j++) {
                    if (i == j)
                        dp[i][j] = new Players((long)v[i], 0);
                    else dp[i][j] = new Players(0, 0);
                }
            

            //Completez si restul matricei, folonsidu-ma de recurenta gasita
            for (k = 2; k <= n; k++)
                for (i = 0; i <= n-k; i++){
                    j = i + k - 1;
                    //Verific care este maximul dintre cele doua numere si completez
                    //elementul la care ma aflu in functie de asta
                    if ( (dp[i+1][j].second + (long)v[i]) > (dp[i][j-1].second + (long)v[j]) )
                        dp[i][j] = new Players(dp[i+1][j].second + (long)v[i], dp[i+1][j].first);
                    else 
                        dp[i][j] = new Players(dp[i][j-1].second + (long)v[j], dp[i][j-1].first);
                }
            
            //Returnez diferenta dintre scorul primului jucator - Tuzgu si scorul
            //celui de-al doilea jucator - Ritza
            return (dp[0][n-1].first - dp[0][n-1].second);
        }

		public void solve() {
			readInput();
			writeOutput(getResult());
		}
	}

	public static void main(String[] args) {
		new Task().solve();
	}
}